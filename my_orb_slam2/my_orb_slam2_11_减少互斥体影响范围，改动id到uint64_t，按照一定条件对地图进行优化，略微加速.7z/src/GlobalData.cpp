#include <iostream>
#include "GlobalData.h"


namespace ORB_SLAM2
{

	GlobalData::GlobalData()
	{
	}

	GlobalData::~GlobalData()
	{
	}

}