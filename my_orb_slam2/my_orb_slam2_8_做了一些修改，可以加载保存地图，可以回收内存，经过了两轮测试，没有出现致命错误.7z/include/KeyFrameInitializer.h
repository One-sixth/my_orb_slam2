#ifndef KEYFRAMEINITIALIZER_H
#define KEYFRAMEINITIALIZER_H

#include <list>
#include <mutex>
#include <opencv2/core.hpp>
#include <DBoW3.h>
#include "GlobalData.h"

using namespace std;

namespace ORB_SLAM2
{

	class KeyFrameDatabase;
	class ORBVocabulary;


	class KeyFrameInitializer
	{
	public:
		KeyFrameInitializer(GlobalData *gd);

		void UndistortKeyPoints();
		bool PosInGrid(const cv::KeyPoint& kp, int &posX, int &posY);
		void AssignFeaturesToGrid();

	public:

		ORBVocabulary *pVocabulary;
		//KeyFrameDatabase *pKeyFrameDatabase;

		long unsigned int nId;
		double TimeStamp;

		float fGridElementWidthInv;
		float fGridElementHeightInv;
		std::vector<std::size_t> vGrid[FRAME_GRID_COLS][FRAME_GRID_ROWS];

		float fx;
		float fy;
		float cx;
		float cy;
		float invfx;
		float invfy;
		float bf;
		float b;
		float ThDepth;
		int N;
		std::vector<cv::KeyPoint> vKps;
		std::vector<cv::KeyPoint> vKpsUn;
		cv::Mat Descriptors;

		//it's zero for mono
		std::vector<float> vRight;
		std::vector<float> vDepth;

		DBoW3::BowVector BowVec;
		DBoW3::FeatureVector FeatVec;

		int nScaleLevels;
		float fScaleFactor;
		float fLogScaleFactor;
		std::vector<float> vScaleFactors;
		std::vector<float> vLevelSigma2;
		std::vector<float> vInvLevelSigma2;
		std::vector<float> vInvScaleFactors;

		int nMinX;
		int nMinY;
		int nMaxX;
		int nMaxY;
		cv::Mat K;
		cv::Mat DistCoef;
	};

}

#endif