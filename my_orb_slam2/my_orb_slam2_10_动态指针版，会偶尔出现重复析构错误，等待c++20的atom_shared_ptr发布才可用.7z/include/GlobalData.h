/*
存放系统全局变量，常量，类静态变量
*/

#ifndef GLOBALDATA_H
#define GLOBALDATA_H

#include <cstdint>
#include <atomic>
#include <opencv2/core.hpp>

using namespace std;

namespace ORB_SLAM2
{

	constexpr auto FRAME_GRID_ROWS = 48;
	constexpr auto FRAME_GRID_COLS = 64;

	class ORBVocabulary;
	class KeyFrameDatabase;
	class Map;
	class Tracking;
	class LocalMapping;
	class LoopClosing;
	class Viewer;
	class FrameDrawer;
	class MapDrawer;


	class GlobalData
	{
	public:
		GlobalData();
		~GlobalData();

		bool LoadData(const cv::FileStorage& fs);

	public:

		//The Vocabulary and KeyFrameDatabase
		ORBVocabulary *mpVocabulary;
		KeyFrameDatabase *mpKeyFrameDatabase;
		Map *mpMap;
		Tracking *mpTracker;
		LocalMapping *mpLocalMapper;
		LoopClosing *mpLoopCloser;
		Viewer* mpViewer;
		FrameDrawer* mpFrameDrawer;
		MapDrawer* mpMapDrawer;

		//Camera parameters
		float width;
		float height;
		float fx;
		float fy;
		float cx;
		float cy;
		float invfx;
		float invfy;
		float bf;
		float b;
		float fps;
		cv::Mat K;
		cv::Mat distCoef;
		bool initialized;

		//Camera RGB parameters
		int nRGB;

		//ORB feature parameters
		int nFeatures;
		float fScaleFactor;
		int nLevels;
		float fIniThFAST;
		float fMinThFAST;

		//other parameters
		float ThDepth = -1;
		float DepthMapFactor = -1;

		// for Frame
		atomic<uint32_t> nFrameNextId = 0;
		bool bFrameInitialComputations = true;
		float nFrameMinX = 0, nFrameMinY = 0, nFrameMaxX = 0, nFrameMaxY = 0;
		float fFrameGridElementWidthInv = 0, fFrameGridElementHeightInv = 0;

		// for KeyFrame
		atomic<uint32_t> nKeyFrameNextId = 0;

		// for MapPoint
		atomic<uint32_t> nMapPointNextId = 0;
		mutex mutexMapPointGlobalPos;

	};

}

#endif